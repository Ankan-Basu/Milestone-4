﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace APIConsume
{
    internal class Customers
    {
        public int cId { get; set; }
        public string cName { get; set; }
        public string cAddress { get; set; }
        public double cWalletBalance { get; set; }
    }
}
