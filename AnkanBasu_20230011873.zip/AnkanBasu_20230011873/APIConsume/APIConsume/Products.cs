﻿using APIConsume;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace APIConsume
{
    internal class Products
    {
        public int pId { get; set; }
        public string pName { get; set; }
        public double pPrice { get; set; }
        public int pAvailableQty { get; set; }
        public string pDescription { get; set; }
        public bool pIsInStock { get; set; }

        int port = 7251;
        public List<Products> GetAllProducts()
        {
            string url = $"https://localhost:{port}/api/products";
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            var call = client.GetAsync(url);
            var response = call.Result;

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var data = response.Content;
                List<Products> productsData = data.ReadAsAsync<List<Products>>().Result;
                call.Wait();
                return productsData;
            }
            else
            {
                throw new Exception("Requested data cannot be fetched");
            }
        }

        public List<Products> GetProductsInRange(double lower, double upper)
        {
            string url = $"https://localhost:{port}/api/products/range?lower={lower}&upper={upper}";
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            var call = client.GetAsync(url);
            var response = call.Result;

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var data = response.Content;
                List<Products> productsData = data.ReadAsAsync<List<Products>>().Result;
                call.Wait();
                return productsData;
            }
            else
            {
                throw new Exception("Requested data cannot be fetched");
            }
        }
    }
}