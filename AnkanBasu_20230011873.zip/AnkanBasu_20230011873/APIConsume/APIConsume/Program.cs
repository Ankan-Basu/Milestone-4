﻿using APIConsume;

Products prodObj = new Products();
var data1 = prodObj.GetAllProducts();

Console.WriteLine("All Products");
Console.WriteLine("pId\tpName\tpPrice\tpAvailableQty\tpDescription\tpIsInStock");
foreach (var item in data1)
{
    Console.WriteLine($"{item.pId}\tpName,\t{item.pPrice}\t{item.pAvailableQty},\t{item.pDescription}\t{item.pIsInStock}");
}
Console.WriteLine("-----------------------------------------------------------\n");
Console.WriteLine();

var data2 = prodObj.GetProductsInRange(10, 15);
Console.WriteLine("Products in price range 10 to 15");
Console.WriteLine("pId\tpName\tpPrice\tpAvailableQty\tpDescription\tpIsInStock");
foreach (var item in data2)
{
    Console.WriteLine($"{item.pId}\tpName,\t{item.pPrice}\t{item.pAvailableQty},\t{item.pDescription}\t{item.pIsInStock}");
}
Console.WriteLine("-----------------------------------------------------------\n");
Console.WriteLine();

Orders ordObj = new Orders();

var data3 = ordObj.GetOrdersByCustId(100);
Console.WriteLine("Orders od customer id 100");
Console.WriteLine("orderId\tcustId\tprodId\tordStatus");
foreach (var item in data3)
{
    Console.WriteLine($"{item.oId}\t{item.cId}\t{item.pId}\t{item.oStatus}");
}
Console.WriteLine("-----------------------------------------------------------\n");
Console.WriteLine();

var data4 = ordObj.GetOrdersInProgress();
Console.WriteLine("Orders in progress");
Console.WriteLine("orderId\tcustId\tprodId\tordStatus");
foreach (var item in data4)
{
    Console.WriteLine($"{item.oId}\t{item.cId}\t{item.pId}\t{item.oStatus}");
}
Console.WriteLine("-----------------------------------------------------------\n");
Console.WriteLine();
