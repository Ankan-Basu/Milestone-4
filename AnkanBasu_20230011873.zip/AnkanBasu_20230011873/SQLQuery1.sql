create database ProductsDB_API;

use productsDB_API;
	
create table products (
	pId int primary key,
	pName varchar(20),
	pPrice float,
	pAvailableQty int, 
	pDescription varchar(30), 
	pIsInStock bit
);

create table customers (
	cId int primary key,
	cName varchar(20),
	cAddress varchar(30),
	cWalletBalance float
);

create table orders (
	oId int primary key,
	cId int foreign key references customers(cId),
	pId int foreign key references products(pId),
	oStatus varchar(20),
	
	constraint chk_oStatus check(oStatus in ('Delivered', 'In Progress', 'Cancelled', 'Failed'))
);

insert into products values (1, 'WaiWai', 15, 200, 'Noodles', 1);
insert into products values (2, 'Good Day', 5, 130, 'Biscuit', 1);
insert into products values (3, 'Bru', 105, 0, 'Coffee', 0);
insert into products values (4, 'SurfExel', 145, 50, 'Detergent', 1);
insert into products values (5, 'LifeBuoy', 10, 103, 'Soap', 1);
insert into products values (6, 'Bisleri', 10, 0, 'Mineral Water', 0);
insert into products values (7, 'Redmi9', 15000, 10, 'Mobile', 1);

insert into customers values (100, 'Mr. Fresh', 'Wuhan', 1221.50);
insert into customers values (101, 'Naruto', 'Konoha', 400.50);
insert into customers values (102, 'Sasuke', 'Konoha', 55.00);
insert into customers values (103, 'Oggy', 'Paris', 1402.50);
insert into customers values (104, 'Cheems', 'Tokyo', 225.50);

insert into orders values (500,	100, 7, 'Delivered');
insert into orders values (501,	101, 1, 'In Progress');
insert into orders values (502,	103, 6, 'Cancelled');
